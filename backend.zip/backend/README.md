Các bước cần làm:

- Dùng npm:
1. Chạy câu lệnh:  npm install --omit=dev

2. Để chạy project, tại root: npm start

=============

- Dùng yarn:
1. chạy câu lệnh: yarn
2. chạy project: yarn start

=============

Lưu ý: với MacOS/Linux, nếu không thấy file .env => google cách hiện , or mở = vscode :v
