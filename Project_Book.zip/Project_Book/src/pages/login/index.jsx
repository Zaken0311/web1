import { useState } from "react";
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import { toast } from 'react-toastify';
import { loginApi } from "../../utils/UserServices";

import { Link, useNavigate } from "react-router-dom";
import { Button, Divider, Form, Input, message, notification } from 'antd';
import { useDispatch, Provider } from "react-redux";


import { CheckCircleOutlined } from '@ant-design/icons';
import { doLoginAction } from "../../redux/account/accountSLice";

const LoginPage = () => {

    const dispatch = useDispatch();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const handleLogin = async (e) => {
        e.preventDefault(); // Prevent the default form submission behavior
        if (!username || !password) {
            toast.error("Please enter username and password");
            return;
        }
        let res = await loginApi(username, password);
        console.log(res)
        if (res && res.statusCode === 201) {
            localStorage.setItem("access_token", res.data.access_token);
            dispatch(doLoginAction(res.data.user));
            message.success('Đăng nhập thành công');
            navigate('/');
        } else {
            if (res && res.statusCode === 400) {
                message.error(res.message);
            }
        }
    };

    return (
        <div className="login-container col-4">
            <div className="title"> Login </div>
            <form onSubmit={handleLogin}>
                <div className="text">Email or username:</div>
                <input
                    type="text"
                    placeholder="Email or username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    autoComplete="username"
                />

                <div>
                    <label htmlFor="password">Password:</label>
                    <div style={{ position: 'relative' }}>
                        <input
                            type={showPassword ? 'text' : 'password'}
                            id="password"
                            value={password}
                            placeholder="Password"
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            autoComplete="current-password"
                            style={{ width: '100%', paddingRight: '40px' }}
                        />
                        <span
                            onClick={togglePasswordVisibility}
                            style={{
                                position: 'absolute',
                                right: '10px',
                                top: '32%',
                                transform: 'translateY(-50%)',
                                cursor: 'pointer',
                            }}
                        >
                            {showPassword ? <FaEyeSlash /> : <FaEye />}
                        </span>
                    </div>
                </div>

                <button
                    className={username && password ? "active" : ""}
                    disabled={!(username && password)}
                    type="submit"
                >
                    Login
                </button>
            </form>

            <p className="my-3 text text-normal">
                Chưa có tài khoản?
                <span>
                    <Link to='/register'> Register </Link>
                </span>
            </p>
        </div>
    );
};

export default LoginPage;
