const ContactPage = () => {

    return (
        <>
        contactPage
        </>
    )
}

export default ContactPage;