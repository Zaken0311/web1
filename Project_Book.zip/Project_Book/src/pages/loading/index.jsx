
import GridLoader  from "react-spinners/GridLoader";

const LoadingPage = () => {

    const style1 = { position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)" };



    return (
        
        
        <div style={style1}>
        <GridLoader  color="#4d7cdc" />

        </div>
        
    )
}
export default LoadingPage;