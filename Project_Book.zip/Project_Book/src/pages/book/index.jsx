const BookPage = ()=>{
    return (
        <>
        book pages
        </>
    )
}
export default BookPage;