import UserTable from "../../../components/Admin/User/UserTable";

const ManagerUser = () => {
    return (
        <>
        <UserTable/>
        </>
    )
}

export default ManagerUser;