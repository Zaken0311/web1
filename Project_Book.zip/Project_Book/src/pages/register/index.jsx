import { useState } from "react";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { registerApi } from "../../utils/UserServices";
import { Link, useNavigate } from "react-router-dom";
import { Button, Divider, Form, Input, message, notification } from 'antd';

const RegisterPage = () => {
  const navigate = useNavigate();
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!fullName || !password || !confirmPassword || !email || !phone) {
      message.error("Please enter all fields");
      return;
    }

    if (password !== confirmPassword) {
      message.error("Passwords do not match!");
      return;
    }

    let res = await registerApi(fullName, email, password, phone);
    if (res && res.statusCode === 201) {
      message.success('Đăng ký tài khoản thành công!');
      navigate('/login');
    } else {
      if (res && res.statusCode === 400) {
        notification.error({
          description: res.message,
          duration: 5
        });
      }
    }
  };

  return (
    <>
      <div className="register-container">
        <div className="title">Register</div>
        
        <div className="text">Fullname:</div>
        <input
          type="text"
          placeholder="Fullname"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
        />

        <div className="text">Email:</div>
        <input
          type="text"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <div>
          <label htmlFor="password">Password:</label>
          <div style={{ position: 'relative' }}>
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              value={password}
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{ width: '100%', paddingRight: '40px' }}
            />
            <span
              onClick={togglePasswordVisibility}
              style={{
                position: 'absolute',
                right: '10px',
                top: '32%',
                transform: 'translateY(-50%)',
                cursor: 'pointer',
              }}
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </span>
          </div>
        </div>

        <div>
          <label htmlFor="confirm-password">Confirm Password:</label>
          <div style={{ position: 'relative' }}>
            <input
              type={showConfirmPassword ? 'text' : 'password'}
              id="confirm-password"
              value={confirmPassword}
              placeholder="Confirm Password"
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              style={{ width: '100%', paddingRight: '40px' }}
            />
            <span
              onClick={toggleConfirmPasswordVisibility}
              style={{
                position: 'absolute',
                right: '10px',
                top: '32%',
                transform: 'translateY(-50%)',
                cursor: 'pointer',
              }}
            >
              {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
            </span>
          </div>
        </div>

        <div className="text">Phone:</div>
        <input
          type="text"
          placeholder="Phone number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />

        <button
          onClick={handleRegister}
        >
          Register
        </button>

        <p className="my-3 text text-normal">
          Already have an account?
          <span>
            <Link to='/login'> Log In </Link>
          </span>
        </p>
      </div>
    </>
  );
};

export default RegisterPage;
