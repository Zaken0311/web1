
import axios from "./axios-custormize";



const registerApi = (fullName, email, password, phone) => {
    return axios.post("api/v1/user/register", {fullName, email, password, phone});
}
const loginApi = (username,password) => {
    return axios.post("/api/v1/auth/login",{username,password});
}

const callFeetAccount = () => {
    return axios.get("/api/v1/auth/account");
}
const callLogout = () => {
    return axios.post('/api/v1/auth/logout')
}
const callFetchListUser = (query) => {
    // current=1&pageSize=3
    return axios.get(`/api/v1/user?${query}`)
}


export {registerApi,loginApi, callFeetAccount, callLogout, callFetchListUser};