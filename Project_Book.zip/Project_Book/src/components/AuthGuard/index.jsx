import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';

const RoleBaseRoute = ({ children }) => {
    const isAdminRole = window.location.pathname.startsWith("/admin");
    const user = useSelector((state) => state.account.user);

    // Trạng thái điều hướng
    const [redirect, setRedirect] = useState(null);

    useEffect(() => {
        if (!user) {
            // Nếu chưa đăng nhập, chuyển hướng đến trang đăng nhập
            setRedirect("/login");
        } else if (isAdminRole && user.role !== 'ADMIN') {
            // Nếu không phải là admin, chuyển đến trang lỗi
            setRedirect("/error");
        }
    }, [user, isAdminRole]);

    if (redirect) {
        return <Navigate to={redirect} replace />;
    }

    return <>{children}</>;
}

const ProtectRoute = ({ children }) => {
    const isAuthentication = useSelector((state) => state.account.isAuthentication);

    return (
        <>
            {isAuthentication ? (
                <RoleBaseRoute>{children}</RoleBaseRoute>
            ) : (
                <Navigate to="/login" replace />
            )}
        </>
    );
}

export default ProtectRoute;
