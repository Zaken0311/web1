import { FaFacebook, FaTwitter, FaInstagram } from "react-icons/fa";

const Footer = () => {
    return (
        <footer style={styles.footer}>
            {/* Social Media Links */}
            <div style={styles.socialMedia}>
                <a href="https://facebook.com" style={styles.socialLink} target="_blank" rel="noopener noreferrer">
                    <FaFacebook />
                </a>
                <a href="https://twitter.com" style={styles.socialLink} target="_blank" rel="noopener noreferrer">
                    <FaTwitter />
                </a>
                <a href="https://instagram.com" style={styles.socialLink} target="_blank" rel="noopener noreferrer">
                    <FaInstagram />
                </a>
            </div>

            {/* Footer Links */}
            <div style={styles.footerLinks}>
                <a href="/terms" style={styles.footerLink}>Điều khoản dịch vụ</a>
                <a href="/privacy" style={styles.footerLink}>Chính sách bảo mật</a>
                <a href="/contact" style={styles.footerLink}>Liên hệ</a>
            </div>

            {/* Copyright Info */}
            <div style={styles.copyright}>
                © 2024 MyShop. All rights reserved.
            </div>
        </footer>
    );
};

const styles = {
    footer: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#333",
        color: "#fff",
        padding: "20px 0",
    },
    socialMedia: {
        display: "flex",
        justifyContent: "center",
        marginBottom: "10px",
    },
    socialLink: {
        color: "#fff",
        margin: "0 10px",
        fontSize: "1.5rem",
        textDecoration: "none",
        transition: "color 0.3s",
    },
    socialLinkHover: {
        color: "#4d7cdc",
    },
    footerLinks: {
        display: "flex",
        justifyContent: "center",
        marginBottom: "10px",
    },
    footerLink: {
        color: "#fff",
        margin: "0 15px",
        textDecoration: "none",
        fontSize: "1rem",
        transition: "color 0.3s",
    },
    footerLinkHover: {
        color: "#4d7cdc",
    },
    copyright: {
        fontSize: "0.9rem",
    },
};

export default Footer;
