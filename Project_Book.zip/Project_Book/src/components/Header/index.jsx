import { FaShoppingCart, FaReact } from "react-icons/fa";
import { DownOutlined } from "@ant-design/icons";
import { Dropdown, Menu, Space } from "antd";
import { useNavigate } from "react-router-dom";
import { callLogout } from "../../utils/UserServices";
import { useDispatch, useSelector } from 'react-redux';
import { doLogoutAction } from "../../redux/account/accountSLice";
import { Button, Divider, Form, Input, message, notification } from 'antd';


const Header = () => {

    const isAuthenticated = useSelector(state => state.account.isAuthenticated);
    const user = useSelector(state => state.account.user);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const hanleLogout = async () => {
        const res = await callLogout();
        if (res && res.data) {
            dispatch(doLogoutAction());
            message.success('Đăng xuất thành công');

            navigate('/');
        }
    }

    const hanleAdmin = () => {
        if (!isAuthenticated||res.statusCode === 401){
            navigate('login')
        }
        navigate('/admin');
    }

    const items = [
        {
            label: <a onClick={() => navigate('/')}>Quản lý tài khoản</a>,
            key: 'account',
        },

        {
            type: 'divider',
        },
        {
            label: <a onClick={() => hanleLogout()}>Đăng xuất</a>,
            key: 'logout',
        },
    ];

    return (
        <header style={styles.header}>
            {/* Logo with animation */}
            <div style={styles.logo}>
                <FaReact style={styles.reactLogo} />
                <h1 onClick={() => navigate('/')}>MyShop</h1>
            </div>

            {/* Search Bar */}
            <div style={styles.searchBar}>
                <input
                    type="text"
                    placeholder="Search for products..."
                    style={styles.searchInput}
                />
            </div>

            {/* Navigation Links */}

            <nav style={styles.nav}>
                <a onClick={() => navigate('/admin')} style={styles.navLink}>AdminPage</a>
                <a href="/products" style={styles.navLink}>Products</a>
                <div style={styles.cartLink}>

                    <FaShoppingCart />
                    <span style={styles.cartCount}>3</span>
                </div>
                <div style={styles.navLink}>
                    {/* <Dropdown menu={{ items }} trigger={['click']}>
                        <a onClick={(e) => e.preventDefault()}>
                            <Space style={styles.navLink}>
                                Welcome, I'm User
                                <DownOutlined />
                            </Space>
                        </a>
                    </Dropdown> */}
                    {!isAuthenticated ?
                        <span onClick={() => navigate('/login')}> Tài Khoản</span>
                        :
                        <Dropdown menu={{ items }} trigger={['click']}>
                            <a onClick={(e) => e.preventDefault()}>
                                <Space>
                                    Welcome {user?.fullName}
                                    <DownOutlined />
                                </Space>
                            </a>
                        </Dropdown>
                    }

                </div>
            </nav>
        </header>
    );
};

// Inline Styles with animation for the React logo
const styles = {
    header: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#4d7cdc",
        color: "#fff",
        padding: "10px 20px",
    },
    logo: {
        display: "flex",
        alignItems: "center",
        fontSize: "1.5rem",
        fontWeight: "bold",
        cursor: "pointer",
    },
    reactLogo: {
        fontSize: "2rem",
        marginRight: "10px",
        animation: "spin 3s linear infinite",
    },
    searchBar: {
        flexGrow: 1,
        marginTop: "20px",
        marginLeft: "20px",
        marginRight: "20px",
    },
    searchInput: {
        width: "100%",
        padding: "5px",
        fontSize: "1rem",
    },
    nav: {
        display: "flex",
        alignItems: "center",
    },
    navLink: {
        marginLeft: "15px",
        color: "#fff",
        textDecoration: "none",
        fontSize: "1rem",
    },
    cartLink: {
        marginLeft: "15px",
        position: "relative",
        color: "#fff",
        textDecoration: "none",
        fontSize: "1.2rem",
    },
    cartCount: {
        position: "absolute",
        top: "-5px",
        right: "-10px",
        backgroundColor: "red",
        color: "white",
        borderRadius: "50%",
        padding: "2px 5px",
        fontSize: "0.8rem",
    },
};

// Add global CSS for animation
const globalStyle = `
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}`;

// Append the style to the head tag
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = globalStyle;
document.head.appendChild(styleSheet);

export default Header;
