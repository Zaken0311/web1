import React, { useEffect, useState } from 'react';
import './App.scss';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import LoginPage from './pages/login/index';
import ContactPage from './pages/contact';
import { Outlet } from 'react-router-dom';
import Footer from './components/Footer';
import Header from './components/Header';
import Home from './components/Home';
import RegisterPage from './pages/register';
import { ToastContainer } from 'react-toastify';
import Container from 'react-bootstrap/Container';
import { callFeetAccount } from './utils/UserServices';
import { useDispatch, useSelector } from 'react-redux';
import { doGetAccountAction } from './redux/account/accountSLice';
import LoadingPage from './pages/loading';
import NotFound from './components/NotFound';
import AdminPage from './pages/admin';
import ProtectRoute from './components/ProtectRoute';
import AuthGuard from './components/AuthGuard';
import LayoutAdmin from './components/Admin/LayoutAdmin';
import ManagerUser from './pages/admin/user';



const Layout = () => {

  return (
    <div className='layout-app'>


      <div className='app-container'>
        <Container>
          <Header />
          <br />
          <Outlet />
          <br />
          <Footer />
        </Container>
      </div>


    </div>
  )
}

export default function App() {

  const dispatch = useDispatch();
  //const isAuthenticated = useSelector((state) => state.account.isAuthenticated);
  const isLoading = useSelector(state => state.account.isLoading)

  const getAccount = async () => {
    if (window.location.pathname === "/login"

      || window.location.pathname === "/register") return;
    const res = await callFeetAccount();
    console.log(res);
    if (res && res.data) {
      dispatch(doGetAccountAction(res.data));
    }

  }


  useEffect(() => {
    getAccount()

  }, [])


  const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      errorElement: <NotFound />,

      children: [
        { index: true, element: <Home /> },
        {
          path: "contacts",
          element: <ContactPage />,
        },
      ],
    },

    {
      path: "/admin",
      element:
        <LayoutAdmin />
      ,
      errorElement: <NotFound />,

      children: [
        { index: true, element: <ProtectRoute><AdminPage /></ProtectRoute> },
        {
          path: "user",
          element: <ProtectRoute><ManagerUser /></ProtectRoute>,
        },
      ],
    },

    {
      path: "/login",
      element: <LoginPage />,
    },
    {
      path: "/register",
      element: <RegisterPage />,
    },
    

  ]);
  return (
    <>
      {
        isLoading === false
          || window.location.pathname === "/login"
          || window.location.pathname === "/"
          || window.location.pathname === "/register"


          ? <RouterProvider router={router} />
          : <LoadingPage />}


    </>
  )
}
